# !/bin/bash
nohup ./go-rad & 
